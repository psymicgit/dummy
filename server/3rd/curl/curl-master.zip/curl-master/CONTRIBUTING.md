How to contribute to curl
=========================

Join the community
------------------

 1. Click 'watch' on the github repo

 2. Subscribe to the suitable [mailing lists](http://curl.haxx.se/mail/)

Read [docs/CONTRIBUTE](docs/CONTRIBUTE)
---------------------------------------

Send your suggestions using one of these methods:
-------------------------------------------------

 1. in a mail to the mailing list

 2. as a pull request on github

 3. as an issue on github
   

/ The cURL team!

