﻿<?php

class init{
	
	//1、测试用公钥，请替换为对应游戏的公钥，从快用平台上获取的是无格式的公钥，需要转换  
  const public_key = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDPXB7aWe9IUh2wz0MyOqxwk3ujF5qmmRzOL4kwfVPVsnEG8d2lSbo+S0/Xm7sivsR1l/LsGWAuoWGLF0bFO5Zm+oh5W6rexuh+mJgAhZfSzrIAgD7QJIZ2TOzQFeCki3xor+62RmEqjePYWJpP0pStVexMZzFaRRFRiYXWMVCeYQIDAQAB';

	public function verify($post_sign,$post_notify_data,$post_orderid,$post_dealseq,$post_uid,$post_uid,$post_subject,$post_v){

		include('log4php/Logger.php');
		include("Rsa.php");
		
		//初始化log4php
		$log = Logger::getLogger('myLogger');
		$date = date('Y-m-d h:i:s');
		
		Logger::configure(array(
		'rootLogger' => array(
		'appenders' => array('default'),
		'level' => 'DEBUG'
				),
				'appenders' => array(
				'default' => array(
				'class' => 'LoggerAppenderFile',
				'layout' => array(
				'class' => 'LoggerLayoutSimple'
						),
						'params' => array(
						'file' => 'myLog.log',
						'append' => true
						)
				)
				)
		));
		

		if($post_sign==""){
			$log->warn($date." Unable to get required value");
			return "failed";
		}
		
		$publicKey = $this::public_key;
		//2、对签名做base64解码
		$post_sign = base64_decode($post_sign);
		
		//3、对输入参数根据参数名排序，并拼接为key=value&key=value格式；
		$parametersArray = array();
		
		$parametersArray['notify_data'] = $post_notify_data;
		$parametersArray['orderid'] = $post_orderid;
		$parametersArray['dealseq'] = $post_dealseq;
		$parametersArray['uid'] = $post_uid;
		$parametersArray['subject'] = $post_subject;
		$parametersArray['v'] = $post_v;
		
		ksort($parametersArray);
		
		$sourcestr="";
		foreach ($parametersArray as $key => $val) {
		
			$sourcestr==""?$sourcestr=$key."=".$val:$sourcestr.="&".$key."=".$val;
		}
		
		
		$log->info($date." Raw sign is: ".$sourcestr);
		
		//4、对数据进行验签，注意对公钥做格式转换
		$publicKey = Rsa::instance()->convert_publicKey($publicKey);
		$verify = Rsa::instance()->verify($sourcestr, $post_sign, $publicKey);
		
		$log->info($date." Verification result is ".$verify);
		
		if($verify!=1){
			$log->warn($date." Failed to verify data");
			return "failed";
		}
		
		//5、对加密的notify_data进行解密
		$post_notify_data = base64_decode($_POST['notify_data']);
		
		$decode_notify_data = Rsa::instance()->publickey_decodeing($post_notify_data, $publicKey);
		
		$log->info($date." Notify data decoded as ".$decode_notify_data);
		
		parse_str($decode_notify_data, $parse);
		$dealseq= $parse['dealseq'];
		$fee= $parse['fee'];//实际支付金额，注意：卡支付时可能出现成功支付额与订单金额不一致的情况，请根据自身业务决定是否按比例做充值。
		$payresult= $parse['payresult'];
		
		$log->info($date." dealseq: ".$dealseq." fee: ".$fee." payresult: ".$payresult);
		
		//6、比较解密出的数据中的dealseq和参数中的dealseq是否一致
		if($dealseq==$_POST['dealseq']){
			$log->info($date." Success");
			//TODO：开发商根据dealseq将支付结果记录下来，并根据支付结果做相应处理
			//注意：卡支付时可能出现成功支付额与订单金额不一致的情况，请根据自身业务决定是否按比例做充值。
			return "success";
		}else{
			$log->warn($date." Dealseq values did not match");
			return "failed";
		}
	}
	
}

?>