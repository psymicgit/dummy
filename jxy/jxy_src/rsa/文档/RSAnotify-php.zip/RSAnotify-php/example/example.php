﻿<?php

header("Content-type: text/html; charset=utf-8");

include('init.php');

$init = new init();
echo $init->verify($_POST['sign'],$_POST['notify_data'],$_POST['orderid'],$_POST['dealseq'],$_POST['uid'],$_POST['uid'],$_POST['subject'],$_POST['v']);

?>